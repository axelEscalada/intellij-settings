package com.aerolineas.MODULE.TEMPLATE.resource.definition;

import javax.validation.Valid;
import javax.ws.rs.core.Response;

import com.aerolineas.MODULE.TEMPLATE.model.TEMPLATEEntity;
import com.aerolineas.core.rest.error.ApiError;
import com.aerolineas.core.rest.pagination.PaginatedResult;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class expose method for the MS CRUD
 */
public interface TEMPLATEDefinition {

    /**
     * This method find all object and return a resulset pagination
     *
     * @param offset starting page number
     * @param limit  how many elements for the page
     * @param sort   name of the property to sort by
     * @param order  ASC or DESC
     * @return a Response with a list of elements
     */
    @ApiOperation(value = "Return example according to code")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Request successful", response = PaginatedResult.class),
        @ApiResponse(code = 400, message = "The request contains missing or invalid information", response = ApiError.class),
        @ApiResponse(code = 401, message = "The request is not validly authenticated", response = ApiError.class),
        @ApiResponse(code = 403, message = "The client is not authorized for using this operation", response = ApiError.class),
        @ApiResponse(code = 404, message = "The resource was not found", response = ApiError.class),
        @ApiResponse(code = 500, message = "There was an error during the execution of the service", response = ApiError.class),
        @ApiResponse(code = 503, message = "Service not available", response = ApiError.class),
    })
    @ApiImplicitParams({
        @ApiImplicitParam(name = "offset", value = "The offset"),
        @ApiImplicitParam(name = "limit", value = "Limit per page"),
        @ApiImplicitParam(name = "sort", value = "Field sorted"),
        @ApiImplicitParam(name = "order", value = "Sort order")
    })
    Response getAllTemplates(Integer offset, Integer limit, String sort, String order);

    /**
     * This method find one object
     */
    @ApiOperation(value = "Returns one TEMPLATE according to id")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Request successful", response = TEMPLATEEntity.class),
        @ApiResponse(code = 400, message = "The request contains missing or invalid information", response = ApiError.class),
        @ApiResponse(code = 401, message = "The request is not validly authenticated", response = ApiError.class),
        @ApiResponse(code = 403, message = "The client is not authorized for using this operation", response = ApiError.class),
        @ApiResponse(code = 404, message = "The resource was not found", response = ApiError.class),
        @ApiResponse(code = 500, message = "There was an error during the execution of the service", response = ApiError.class),
        @ApiResponse(code = 503, message = "Service not available", response = ApiError.class),
    })
    @ApiImplicitParam(name = "id", value = "TEMPLATE id", required = true)
    Response getOneTemplate(String id);

    /**
     * This method create a object
     */
    @ApiOperation(value = "Create an TemplateModel")
    @ApiResponses(value = {
        @ApiResponse(code = 201, message = "The resource has been successfully created", response = TEMPLATEEntity.class),
        @ApiResponse(code = 400, message = "The request contains missing or invalid information", response = ApiError.class),
        @ApiResponse(code = 401, message = "The request is not validly authenticated", response = ApiError.class),
        @ApiResponse(code = 403, message = "The client is not authorized for using this operation", response = ApiError.class),
        @ApiResponse(code = 409, message = "The resource already exists", response = ApiError.class),
        @ApiResponse(code = 500, message = "There was an error during the execution of the service", response = ApiError.class),
        @ApiResponse(code = 503, message = "Service not available", response = ApiError.class),
    })
    @ApiImplicitParam(name = "TEMPLATE", value = "An TEMPLATE", required = true)
    Response createTemplate(@Valid TEMPLATEEntity TEMPLATEEntity);

    /**
     * This method update a object
     */
    @ApiOperation(value = "Updates one TemplateModel according to id")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "The resource has been successfully updated", response = TEMPLATEEntity.class),
        @ApiResponse(code = 400, message = "The request contains missing or invalid information", response = ApiError.class),
        @ApiResponse(code = 401, message = "The request is not validly authenticated", response = ApiError.class),
        @ApiResponse(code = 403, message = "The client is not authorized for using this operation", response = ApiError.class),
        @ApiResponse(code = 404, message = "The resource was not found", response = ApiError.class),
        @ApiResponse(code = 500, message = "There was an error during the execution of the service", response = ApiError.class),
        @ApiResponse(code = 503, message = "Service not available", response = ApiError.class),
    })
    @ApiImplicitParam(name = "id", value = "Template id", required = true)
    Response updateTemplate(String id, @Valid TEMPLATEEntity TEMPLATEEntityUpdate);

    /**
     * This method delete a object
     */
    @ApiOperation(value = "Delete an TemplateModel according to id")
    @ApiResponses(value = {
        @ApiResponse(code = 204, message = "The resource has been successfully deleted"),
        @ApiResponse(code = 401, message = "The request is not validly authenticated", response = ApiError.class),
        @ApiResponse(code = 403, message = "The client is not authorized for using this operation", response = ApiError.class),
        @ApiResponse(code = 404, message = "The resource was not found", response = ApiError.class),
        @ApiResponse(code = 500, message = "There was an error during the execution of the service", response = ApiError.class),
        @ApiResponse(code = 503, message = "Service not available", response = ApiError.class),
    })
    @ApiImplicitParam(name = "id", value = "TemplateModel id", required = true)
    Response deleteTemplate(String id);
}