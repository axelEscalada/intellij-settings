package com.aerolineas.MODULE.TEMPLATE.service.implementation;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import com.aerolineas.MODULE.TEMPLATE.model.TEMPLATEEntity;
import com.aerolineas.core.exception.factory.ExceptionFactoryBean;

/**
 * TemplateModel has its own service because it works without a business unique code, it uses id.
 */
@Validated
@Service
public class TEMPLATEService{

    protected ExceptionFactoryBean exceptionFactoryBean;

    public TEMPLATEEntity doSomething(String id) {
        return null;
    }

    public String sayHello() {
        return "Hello World!!";
    }

    public TEMPLATEEntity returnSomething() {
        return new TEMPLATEEntity("Hello");
    }

    public void throwException() {
        throw exceptionFactoryBean.createServiceException("TEMPLATEService.test.exception", "Test");
    }
}