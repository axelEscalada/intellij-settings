package com.aerolineas.MODULE.TEMPLATE.model;

import java.io.Serializable;
import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;

/**
 * This class is a test for the TEMPLATE project, which must be deleted or modified for an MS
 */
@ApiModel(value = "TEMPLATE")
public class TEMPLATEEntity implements Serializable {

    @NotEmpty(message = "${TEMPLATEEntity.empty.id}")
    private String id;

    public TEMPLATEEntity() {
    }

    public TEMPLATEEntity(String id) {
        this.id = id;
    }
}