package com.aerolineas.MODULE.TEMPLATE.config;

import java.util.Locale;
import javax.ws.rs.ApplicationPath;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import com.aerolineas.MODULE.TEMPLATE.resource.implementacion.TEMPLATEResource;
import com.aerolineas.core.exception.configuration.ExceptionMapperRegister;
import com.aerolineas.core.rest.config.ApiInformation;
import com.aerolineas.core.rest.config.BaseApiConfiguration;

/**
 * Microservice swagger configuration
 */
@Configuration
@ApplicationPath("${spring.jersey.application-path}")
public class TEMPLATEConfiguration extends BaseApiConfiguration {

    public static final Locale DEFAULT_LOCALE = new Locale("es", "AR");

    @Autowired
    private Environment environment;

    /**
     * Here you must register every Jersey resource or custom ExceptionHandler implementation
     */
    public TEMPLATEConfiguration() {
        super();
        register(TEMPLATEResource.class);
        ExceptionMapperRegister.registerDefaultMappers(this);
        ExceptionMapperRegister.registerBadRequestExceptionMapper(this);
        ExceptionMapperRegister.registerEntityAlreadyExistsExceptionMapper(this);
        ExceptionMapperRegister.registerEntityDoesNotExistsExceptionMapper(this);
        ExceptionMapperRegister.registerServiceExceptionMapper(this);
    }

    /**
     * Fills apiInformation object with API data for swagger documentation
     *
     * @return an apiInformation object
     */
    @Override
    protected ApiInformation getApiInformation() {
        ApiInformation apiInformation = new ApiInformation();
        apiInformation.setTitle("TEMPLATE Data Service");
        apiInformation.setBasePath(environment.getProperty("spring.jersey.application-path"));
        apiInformation.setResourcePackage(environment.getProperty("application.resource-package"));
        return apiInformation;
    }
}