package com.aerolineas.MODULE.TEMPLATE.resource.implementacion;

import javax.validation.Valid;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import com.aerolineas.MODULE.TEMPLATE.model.TEMPLATEEntity;
import com.aerolineas.MODULE.TEMPLATE.resource.definition.TEMPLATEDefinition;
import com.aerolineas.MODULE.TEMPLATE.service.implementation.TEMPLATEService;
import com.aerolineas.core.rest.pagination.PaginatedResult;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;

/**
 * This class implementation the CRUD of MS
 */
@Api(value = "CRUD operations for TEMPLATE")
@Path("/TEMPLATE_RESOURCE")
public class TEMPLATEResource implements TEMPLATEDefinition {

    @Autowired
    private TEMPLATEService service;

    @Override
    @GET
    @Path("/example")
    public Response getAllTemplates(
        @QueryParam("offset") Integer offset,
        @QueryParam("limit") Integer limit,
        @QueryParam("sort") String sort,
        @QueryParam("order") String order) {
        PageImpl<TEMPLATEEntity> page = new PageImpl<>(Lists.newArrayList(service.returnSomething()));

        return Response.status(Response.Status.OK).entity(PaginatedResult.build(page, offset, limit)).build();
    }

    @Override
    @GET
    @Path("/{code}")
    public Response getOneTemplate(@PathParam("code") String id) {
        return Response.ok(service.returnSomething()).build();
    }

    @Override
    @POST
    public Response createTemplate(@Valid TEMPLATEEntity TEMPLATEEntity) {
        return Response.ok().build();
    }

    @Override
    @PUT
    @Path("/{code}")
    public Response updateTemplate(@PathParam("code") String id, @Valid TEMPLATEEntity TEMPLATEEntityUpdate) {
        return Response.ok().build();
    }

    @Override
    @DELETE
    @Path("/{code}")
    public Response deleteTemplate(@PathParam("code") String id) {
        return Response.ok().build();
    }

    @Path("/fails")
    public Response failureExample() {
        service.throwException();
        return Response.serverError().build();
    }

    public void setService(TEMPLATEService templateService) {
        service = templateService;
    }
}