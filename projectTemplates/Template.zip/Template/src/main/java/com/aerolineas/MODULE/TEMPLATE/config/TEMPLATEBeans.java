package com.aerolineas.MODULE.TEMPLATE.config;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import com.aerolineas.core.exception.configuration.ExceptionMessagesConfiguration;
import com.aerolineas.core.exception.factory.ExceptionFactoryBean;

/**
 * You must register every bean implementation
 */
@Configuration
public class TEMPLATEBeans {

    public static final Locale DEFAULT_LOCALE = new Locale("es", "AR");

    /**
     * this method build the base exception
     *
     * @return ExceptionFactoryBean
     */
    @Bean
    public ExceptionFactoryBean exceptionFactoryBean() {
        return new ExceptionFactoryBean();
    }

    /**
     * this method build the factory validator
     *
     * @return factory.getValidator();
     */
    @Bean
    public Validator validator() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        return factory.getValidator();
    }

    /**
     * this method returns the message of the exception described in the messages.properties file
     *
     * @return bean
     */
    @Bean
    public ExceptionMessagesConfiguration exceptionMessagesConfiguration() {
        ReloadableResourceBundleMessageSource bean = new ReloadableResourceBundleMessageSource();
        bean.setBasename("classpath:messages");
        bean.setDefaultEncoding(StandardCharsets.UTF_8.displayName());
        return new ExceptionMessagesConfiguration(DEFAULT_LOCALE, bean);
    }
}