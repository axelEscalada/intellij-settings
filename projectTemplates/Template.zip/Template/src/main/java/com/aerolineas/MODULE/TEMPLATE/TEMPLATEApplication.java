package com.aerolineas.MODULE.TEMPLATE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main class
 */
@SpringBootApplication
public class TEMPLATEApplication {
    public static void main(String[] args) {
        SpringApplication.run(TEMPLATEApplication.class, args);
    }
}