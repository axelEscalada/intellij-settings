package com.aerolineas.MODULE.TEMPLATE.config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
    classes = {TEMPLATEBeans.class},
    loader = AnnotationConfigContextLoader.class)
@SpringBootTest
public class TEMPLATEConfigurationTest {

    @Before
    public void setUp() {}

    @Test
    public void shouldLoadContext() {
    }
}