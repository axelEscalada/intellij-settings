
# README #

### What is this repository for? ###
This repository contains the microservice TEMPLATE, which is used as a generic example for future microservices

### files and word that must be changed ###

The implementation guidelines must be followed and for that, everything referring to the word "TEMPLATE" must be changed within the project Classes, variables and packages.

| fiel                      |      Variable                                        | Line |
|---------------------------|------------------------------------------------------|------|
| build.gradle              | group                                                |  35  |
|                           | spring.application.name                              |  2   |
| appication.properties     | spring.jersey.application-path                       |  3   |
|                           | application.resource-package                         |  4   |
| docker-compose.yml        | image                                                |  7   |
| Dockerfile                | COPY                                                 |  7   |
| Makefile                  | image                                                |  1   |
| settings.gradle           | rootProject.name                                     |  1   |


The default port: 3030

##### Important: remove all information regarding the modification of default files by the template project in the "ReadMe.md" 


### Building ###

| Command        |      Description                                     |
|----------------|------------------------------------------------------|
| make           | Build the artifact and generate the docker image     |
| make build     | Build the artifact using gradlew (wrapper)           |
| make push      | Push docker image to Hub                             |
| make publish   | Publish artifact in Repo                             |
| make clean     | Clean up using gradlew                               |
| make update    | Pull new docker images (FROM image of Dockerfile)    |
| make refresh   | Build the artifact with --refresh-dep param          |
| make shell     | Run a shell inside a running container               |
| make logs      | See logs for a running container                     |
| make test      | Run an artifact test using gradlew                   |
| make buildOnly | Run an artifact test using gradlew                   |

### Running ###
To run the microservice and dependencies use: 

 * ```docker-compose up``` (will attach the output and show the logs) 
 * ```docker-compose up -d``` (will run in background)

### Debug Mode ###
If you need debug mode enabled for Java, please uncomment the line 'entrypoint' in t
he docker-compose.yml file